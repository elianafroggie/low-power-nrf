#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <hal/nrf_gpio.h>
#include <zephyr/sys/poweroff.h>
#include <modem/nrf_modem_lib.h>
#include <nrf_modem_at.h>

/* LED aliases */
#define LED0_NODE DT_ALIAS(led0)
#define LED1_NODE DT_ALIAS(led1)
#define LED2_NODE DT_ALIAS(led2)

static void gpio_high_z(uint32_t pin)
{
    nrf_gpio_cfg(pin,
                 NRF_GPIO_PIN_DIR_INPUT,
                 NRF_GPIO_PIN_INPUT_DISCONNECT,
                 NRF_GPIO_PIN_NOPULL,
                 NRF_GPIO_PIN_S0S1,
                 NRF_GPIO_PIN_NOSENSE);
}

/* LED devices */
static const struct gpio_dt_spec led0 = GPIO_DT_SPEC_GET(LED0_NODE, gpios);
static const struct gpio_dt_spec led1 = GPIO_DT_SPEC_GET(LED1_NODE, gpios);
static const struct gpio_dt_spec led2 = GPIO_DT_SPEC_GET(LED2_NODE, gpios);

#define FLASH_CS_PIN NRF_GPIO_PIN_MAP(0, 20)

#define LPUART_REQ_PIN NRF_GPIO_PIN_MAP(0, 14)
#define LPUART_RDY_PIN NRF_GPIO_PIN_MAP(0, 15)
#define LPUART_RX_PIN  NRF_GPIO_PIN_MAP(0, 26)
#define LPUART_TX_PIN  NRF_GPIO_PIN_MAP(0, 27)

static void lpuart_pins_neutralize(void)
{
    gpio_high_z(LPUART_REQ_PIN);
    gpio_high_z(LPUART_RDY_PIN);
    gpio_high_z(LPUART_RX_PIN);
    gpio_high_z(LPUART_TX_PIN);
}

static void flash_deselect(void)
{
    /*
     * Set the output latch before configuring the pin as an output,
     * preventing a brief low pulse.
     */
    nrf_gpio_pin_set(FLASH_CS_PIN);
    nrf_gpio_cfg_output(FLASH_CS_PIN);
    nrf_gpio_pin_set(FLASH_CS_PIN);
}

static void leds_off(void)
{
    gpio_pin_configure_dt(&led0, GPIO_OUTPUT_INACTIVE);
    gpio_pin_configure_dt(&led1, GPIO_OUTPUT_INACTIVE);
    gpio_pin_configure_dt(&led2, GPIO_OUTPUT_INACTIVE);

    /* Logical 0 = physical HIGH because GPIO_ACTIVE_LOW. */
    gpio_pin_set_dt(&led0, 0);
    gpio_pin_set_dt(&led1, 0);
    gpio_pin_set_dt(&led2, 0);
}

static void gnss_lna_disable(void)
{
	int err;

	err = nrf_modem_lib_init();
	if (err != 0) {
		gpio_pin_set_dt(&led0, 1);;
	}

	/*
	 * COEX0 drives GPS_EN. Drive it high only while the modem is using
	 * the GNSS frequency range; it is driven low when RF is off.
	 */
	err = nrf_modem_at_printf("AT%%XCOEX0");
	if (err != 0) {
		gpio_pin_set_dt(&led1, 1);;
		return;
	}

	/* RF off also commits the COEX0 configuration to modem NVM. */
	err = nrf_modem_at_printf("AT+CFUN=0");
	if (err != 0) {
		gpio_pin_set_dt(&led2, 1);;
		return;
	}

	(void)nrf_modem_lib_shutdown();
}

int main(void)
{
	flash_deselect();
	leds_off();
	gnss_lna_disable();
	lpuart_pins_neutralize();
	k_sleep(K_SECONDS(8));
	sys_poweroff();

	return 0;
}
