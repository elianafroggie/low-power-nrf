#include <zephyr/kernel.h>
#include <zephyr/init.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/sys/poweroff.h>

#include <hal/nrf_gpio.h>
#include <hal/nrf_reset.h>

#define LPUART_TX_PIN  NRF_GPIO_PIN_MAP(0, 20)
#define LPUART_RX_PIN  NRF_GPIO_PIN_MAP(0, 22)
#define LPUART_REQ_PIN NRF_GPIO_PIN_MAP(1, 0)
#define LPUART_RDY_PIN NRF_GPIO_PIN_MAP(1, 1)

static void gpio_high_z(uint32_t pin)
{
    nrf_gpio_cfg(pin,
                 NRF_GPIO_PIN_DIR_INPUT,
                 NRF_GPIO_PIN_INPUT_DISCONNECT,
                 NRF_GPIO_PIN_NOPULL,
                 NRF_GPIO_PIN_S0S1,
                 NRF_GPIO_PIN_NOSENSE);
}

static void lpuart_pins_neutralize(void)
{
    gpio_high_z(LPUART_TX_PIN);
    gpio_high_z(LPUART_RX_PIN);
    gpio_high_z(LPUART_REQ_PIN);
    gpio_high_z(LPUART_RDY_PIN);
}

static int network_core_force_off(void)
{
	/*
	 * Hold CPUNET in force-off from the earliest application-core init stage.
	 * This resets the network core and switches off its power and clocks.
	 */
	nrf_reset_network_force_off(NRF_RESET, true);

	return 0;
}

SYS_INIT(network_core_force_off, PRE_KERNEL_1, 0);

static const struct gpio_dt_spec led0 =
    GPIO_DT_SPEC_GET(DT_NODELABEL(led0), gpios);

static const struct gpio_dt_spec led1 =
    GPIO_DT_SPEC_GET(DT_NODELABEL(led1), gpios);

static const struct gpio_dt_spec led2 =
    GPIO_DT_SPEC_GET(DT_NODELABEL(led2), gpios);

static void leds_off(void)
{
    gpio_pin_configure_dt(&led0, GPIO_OUTPUT_INACTIVE);
    gpio_pin_configure_dt(&led1, GPIO_OUTPUT_INACTIVE);
    gpio_pin_configure_dt(&led2, GPIO_OUTPUT_INACTIVE);

    /* Logical 0 = physical HIGH because GPIO_ACTIVE_LOW. */
    gpio_pin_set_dt(&led0, 0);
    gpio_pin_set_dt(&led1, 0);
    gpio_pin_set_dt(&led2, 0);
}

int main(void)
{
	leds_off();
	lpuart_pins_neutralize();
	k_sleep(K_SECONDS(5));
	network_core_force_off();
	k_sleep(K_SECONDS(5));
	sys_poweroff();

	return 0;
}
